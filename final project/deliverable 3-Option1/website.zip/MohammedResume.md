![Bart Simpson](Bart_Simpson_200px.png)

### Mohammed Hamdan
---
Paterson, NJ 07503 ◆ 973-980-0327 ◆ mthamdan@students.pccc.edu

### Professional Summary
Knowledgeable Customer Service Representative with problem-solving abilities capable of building
customer rapport. Effectively handles customer concerns with clear communication and patience. Able to
take on various tasks at a customer-focused environment.

### Work History
**SOC Supervisor,** 06/2020 to Current Gardaworld – Franklin Lakes, NJ
* Training Staff.
* Enforcing client procedures.
* Report Taking, Wiriting, Emergency Response.


**General Manager**, 08/2018 to 06/2021 Charleys Philly Steaks – Arlington, GA
* Training and Hiring New Hires.
* Providing exceptional Customer Service Skills.
* Taking Inventory.

**Parts Manager, 12/2017 to 06/2018** Toyota Universe – Little Falls, NJ
* Providing Orders for Customers
* Helping techs receive proper parts for vehicles.
* Maintained inventory every part.

 #### Skills

 | **Technical**       | **Communications**   |
 | ------------------- | -------------------- |
 | Microsoft Suite     | Customer Service Oriented |
 | CDK | Team Communication     |


#### Education

| **Degree**        |**School**  | **Year**  |
| ----------------- | ---------- | -------- |
| Associates Degree | PCCC       | 2024    |
